import React from 'react';

function BlankScreen() {
  return (
    <div className="min-h-screen bg-white">
      {/* Intentionally left blank */}
    </div>
  );
}

export default BlankScreen;