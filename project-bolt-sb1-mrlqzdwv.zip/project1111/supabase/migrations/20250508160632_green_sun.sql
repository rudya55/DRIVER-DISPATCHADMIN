/*
  # Add invoice settings table

  1. New Tables
    - `invoice_settings`
      - `id` (uuid, primary key)
      - `company_name` (text)
      - `address` (text)
      - `postal_code` (text)
      - `city` (text)
      - `siret` (text)
      - `vat_number` (text)
      - `phone` (text)
      - `email` (text)
      - `logo_url` (text)
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)

  2. Security
    - Enable RLS
    - Add policies for authenticated users to read/write settings
*/

CREATE TABLE invoice_settings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  company_name text NOT NULL,
  address text NOT NULL,
  postal_code text NOT NULL,
  city text NOT NULL,
  siret text NOT NULL,
  vat_number text NOT NULL,
  phone text NOT NULL,
  email text NOT NULL,
  logo_url text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE invoice_settings ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Users can read invoice settings"
  ON invoice_settings
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Users can update invoice settings"
  ON invoice_settings
  FOR UPDATE
  TO authenticated
  USING (true);

CREATE POLICY "Users can insert invoice settings"
  ON invoice_settings
  FOR INSERT
  TO authenticated
  WITH CHECK (true);