/*
  # Create clients, quotes, and invoices tables

  1. New Tables
    - `clients`
      - `id` (uuid, primary key)
      - `name` (text)
      - `type` (text) - 'company' or 'individual'
      - `siret` (text, nullable)
      - `vat_number` (text, nullable)
      - `address` (text)
      - `postal_code` (text)
      - `city` (text)
      - `email` (text)
      - `phone` (text)
      - `contact_name` (text, nullable)
      - `contact_role` (text, nullable)
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)

    - `quotes`
      - `id` (uuid, primary key)
      - `number` (text, unique)
      - `client_id` (uuid, foreign key)
      - `client_type` (text)
      - `description` (text)
      - `quantity` (integer)
      - `unit_price_ttc` (decimal)
      - `unit_price_ht` (decimal)
      - `amount_ht` (decimal)
      - `amount_ttc` (decimal)
      - `vat_rate` (decimal)
      - `status` (text) - 'pending', 'accepted', 'rejected'
      - `date` (date)
      - `due_date` (date)
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)

    - `invoices`
      - `id` (uuid, primary key)
      - `number` (text, unique)
      - `client_id` (uuid, foreign key)
      - `quote_id` (uuid, foreign key, nullable)
      - `client_type` (text)
      - `description` (text)
      - `quantity` (integer)
      - `unit_price_ttc` (decimal)
      - `unit_price_ht` (decimal)
      - `amount_ht` (decimal)
      - `amount_ttc` (decimal)
      - `vat_rate` (decimal)
      - `status` (text) - 'pending', 'paid'
      - `date` (date)
      - `due_date` (date)
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)

  2. Security
    - Enable RLS on all tables
    - Add policies for authenticated users to read/write all data
*/

-- Create clients table
CREATE TABLE IF NOT EXISTS clients (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  type text NOT NULL CHECK (type IN ('company', 'individual')),
  siret text,
  vat_number text,
  address text NOT NULL,
  postal_code text NOT NULL,
  city text NOT NULL,
  email text NOT NULL,
  phone text NOT NULL,
  contact_name text,
  contact_role text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create quotes table
CREATE TABLE IF NOT EXISTS quotes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  number text UNIQUE,
  client_id uuid REFERENCES clients(id) ON DELETE CASCADE,
  client_type text NOT NULL CHECK (client_type IN ('company', 'individual')),
  description text NOT NULL,
  quantity integer NOT NULL DEFAULT 1,
  unit_price_ttc decimal(10,2) NOT NULL,
  unit_price_ht decimal(10,2) NOT NULL,
  amount_ht decimal(10,2) NOT NULL,
  amount_ttc decimal(10,2) NOT NULL,
  vat_rate decimal(5,2) NOT NULL DEFAULT 10,
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'accepted', 'rejected')),
  date date NOT NULL,
  due_date date NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create invoices table
CREATE TABLE IF NOT EXISTS invoices (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  number text UNIQUE,
  client_id uuid REFERENCES clients(id) ON DELETE CASCADE,
  quote_id uuid REFERENCES quotes(id) ON DELETE SET NULL,
  client_type text NOT NULL CHECK (client_type IN ('company', 'individual')),
  description text NOT NULL,
  quantity integer NOT NULL DEFAULT 1,
  unit_price_ttc decimal(10,2) NOT NULL,
  unit_price_ht decimal(10,2) NOT NULL,
  amount_ht decimal(10,2) NOT NULL,
  amount_ttc decimal(10,2) NOT NULL,
  vat_rate decimal(5,2) NOT NULL DEFAULT 10,
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'paid')),
  date date NOT NULL,
  due_date date NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE clients ENABLE ROW LEVEL SECURITY;
ALTER TABLE quotes ENABLE ROW LEVEL SECURITY;
ALTER TABLE invoices ENABLE ROW LEVEL SECURITY;

-- Create policies for clients
CREATE POLICY "Users can read clients"
  ON clients
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Users can insert clients"
  ON clients
  FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Users can update clients"
  ON clients
  FOR UPDATE
  TO authenticated
  USING (true);

CREATE POLICY "Users can delete clients"
  ON clients
  FOR DELETE
  TO authenticated
  USING (true);

-- Create policies for quotes
CREATE POLICY "Users can read quotes"
  ON quotes
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Users can insert quotes"
  ON quotes
  FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Users can update quotes"
  ON quotes
  FOR UPDATE
  TO authenticated
  USING (true);

CREATE POLICY "Users can delete quotes"
  ON quotes
  FOR DELETE
  TO authenticated
  USING (true);

-- Create policies for invoices
CREATE POLICY "Users can read invoices"
  ON invoices
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Users can insert invoices"
  ON invoices
  FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Users can update invoices"
  ON invoices
  FOR UPDATE
  TO authenticated
  USING (true);

CREATE POLICY "Users can delete invoices"
  ON invoices
  FOR DELETE
  TO authenticated
  USING (true);

-- Insert sample data
INSERT INTO clients (name, type, siret, vat_number, address, postal_code, city, email, phone, contact_name, contact_role) VALUES
('FastTaxi SARL', 'company', '123 456 789 00001', 'FR12345678900', '15 Rue de la Paix', '75002', 'Paris', 'contact@fasttaxi.com', '+33 1 23 45 67 89', 'Jean Martin', 'Directeur'),
('Sophie Bernard', 'individual', NULL, NULL, '25 Avenue des Champs-Élysées', '75008', 'Paris', 'sophie.bernard@email.com', '+33 6 12 34 56 78', NULL, NULL),
('SpeedCab SAS', 'company', '987 654 321 00001', 'FR98765432100', '30 Boulevard Saint-Germain', '75005', 'Paris', 'contact@speedcab.com', '+33 1 98 76 54 32', 'Marie Dubois', 'Responsable flotte');