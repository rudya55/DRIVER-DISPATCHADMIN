import { serve } from 'https://deno.land/std@0.168.0/http/server.ts';
import { google } from 'npm:googleapis@126';
import { createClient } from 'npm:@supabase/supabase-js@2.39.3';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, GET, PUT, DELETE, OPTIONS'
};

// Initialize Google Drive API
const auth = new google.auth.GoogleAuth({
  credentials: {
    client_email: Deno.env.get('GOOGLE_CLIENT_EMAIL'),
    private_key: Deno.env.get('GOOGLE_PRIVATE_KEY')?.replace(/\\n/g, '\n'),
    client_id: Deno.env.get('GOOGLE_CLIENT_ID'),
  },
  scopes: ['https://www.googleapis.com/auth/drive.file']
});

const drive = google.drive({ version: 'v3', auth });

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const url = new URL(req.url);
    const path = url.pathname.split('/').pop();

    // Initialize Supabase client
    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_ANON_KEY') ?? ''
    );

    // Get auth user
    const authHeader = req.headers.get('Authorization');
    if (!authHeader) {
      throw new Error('No authorization header');
    }

    const { data: { user }, error: userError } = await supabaseClient.auth.getUser(
      authHeader.replace('Bearer ', '')
    );

    if (userError || !user) {
      throw new Error('Unauthorized');
    }

    // Handle different API endpoints
    switch (path) {
      case 'upload-document':
        if (req.method !== 'POST') {
          throw new Error('Method not allowed');
        }

        const formData = await req.formData();
        const file = formData.get('file');
        
        if (!file || !(file instanceof File)) {
          throw new Error('No file provided');
        }

        // Upload to Google Drive
        const fileMetadata = {
          name: file.name,
          parents: [Deno.env.get('GOOGLE_DRIVE_FOLDER_ID')]
        };

        const media = {
          mimeType: file.type,
          body: file.stream()
        };

        const driveResponse = await drive.files.create({
          requestBody: fileMetadata,
          media: media,
          fields: 'id, webViewLink'
        });

        // Save reference in Supabase
        const { data: docData, error: docError } = await supabaseClient
          .from('documents')
          .insert({
            user_id: user.id,
            file_name: file.name,
            drive_id: driveResponse.data.id,
            drive_link: driveResponse.data.webViewLink
          })
          .select()
          .single();

        if (docError) {
          throw docError;
        }

        return new Response(
          JSON.stringify(docData),
          { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );

      case 'get-documents':
        if (req.method !== 'GET') {
          throw new Error('Method not allowed');
        }

        const { data: docs, error: docsError } = await supabaseClient
          .from('documents')
          .select('*')
          .eq('user_id', user.id)
          .order('created_at', { ascending: false });

        if (docsError) {
          throw docsError;
        }

        return new Response(
          JSON.stringify(docs),
          { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );

      default:
        throw new Error('Not found');
    }
  } catch (error) {
    return new Response(
      JSON.stringify({ error: error.message }),
      { 
        status: 400,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      }
    );
  }
});