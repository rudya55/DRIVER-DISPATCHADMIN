/*
  # Fix RLS policies for clients table

  1. Security
    - Enable RLS on clients table
    - Add policies for authenticated users to:
      - Insert new clients
      - Read all clients
      - Update clients
      - Delete clients
*/

-- Enable RLS
ALTER TABLE clients ENABLE ROW LEVEL SECURITY;

-- Drop existing policies if they exist
DROP POLICY IF EXISTS "Users can insert clients" ON clients;
DROP POLICY IF EXISTS "Users can read clients" ON clients;
DROP POLICY IF EXISTS "Users can update clients" ON clients;
DROP POLICY IF EXISTS "Users can delete clients" ON clients;

-- Create new policies
CREATE POLICY "Users can insert clients"
ON clients FOR INSERT
TO authenticated
WITH CHECK (true);

CREATE POLICY "Users can read clients"
ON clients FOR SELECT
TO authenticated
USING (true);

CREATE POLICY "Users can update clients"
ON clients FOR UPDATE
TO authenticated
USING (true);

CREATE POLICY "Users can delete clients"
ON clients FOR DELETE
TO authenticated
USING (true);