/*
  # Add company information and automatic numbering

  1. New Tables
    - `company_info`
      - `id` (uuid, primary key)
      - `name` (text)
      - `address` (text)
      - `postal_code` (text)
      - `city` (text)
      - `siret` (text)
      - `vat_number` (text)
      - `phone` (text)
      - `email` (text)

  2. Changes
    - Add number generation function
    - Add triggers for automatic numbering on quotes and invoices
*/

-- Create company_info table
CREATE TABLE company_info (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  address text NOT NULL,
  postal_code text NOT NULL,
  city text NOT NULL,
  siret text NOT NULL,
  vat_number text NOT NULL,
  phone text NOT NULL,
  email text NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE company_info ENABLE ROW LEVEL SECURITY;

-- Create policy for authenticated users
CREATE POLICY "Users can read company info"
  ON company_info
  FOR SELECT
  TO authenticated
  USING (true);

-- Function to generate sequential numbers
CREATE OR REPLACE FUNCTION generate_document_number(prefix text)
RETURNS text
LANGUAGE plpgsql
AS $$
DECLARE
  year text := to_char(current_date, 'YYYY');
  last_number int;
  new_number text;
BEGIN
  IF prefix = 'DEV-' THEN
    SELECT COALESCE(MAX(NULLIF(regexp_replace(number, '^DEV-\d{4}-(\d+)$', '\1'), '')), '0')::int
    INTO last_number
    FROM quotes
    WHERE number LIKE 'DEV-' || year || '-%';
  ELSE
    SELECT COALESCE(MAX(NULLIF(regexp_replace(number, '^FAC-\d{4}-(\d+)$', '\1'), '')), '0')::int
    INTO last_number
    FROM invoices
    WHERE number LIKE 'FAC-' || year || '-%';
  END IF;

  new_number := prefix || year || '-' || lpad((last_number + 1)::text, 4, '0');
  RETURN new_number;
END;
$$;

-- Trigger function for quotes
CREATE OR REPLACE FUNCTION set_quote_number()
RETURNS TRIGGER AS $$
BEGIN
  IF NEW.number IS NULL THEN
    NEW.number := generate_document_number('DEV-');
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Trigger function for invoices
CREATE OR REPLACE FUNCTION set_invoice_number()
RETURNS TRIGGER AS $$
BEGIN
  IF NEW.number IS NULL THEN
    NEW.number := generate_document_number('FAC-');
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create triggers
CREATE TRIGGER set_quote_number_trigger
  BEFORE INSERT ON quotes
  FOR EACH ROW
  EXECUTE FUNCTION set_quote_number();

CREATE TRIGGER set_invoice_number_trigger
  BEFORE INSERT ON invoices
  FOR EACH ROW
  EXECUTE FUNCTION set_invoice_number();