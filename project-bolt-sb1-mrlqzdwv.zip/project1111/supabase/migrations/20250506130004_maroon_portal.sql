/*
  # Create rides and messages tables

  1. New Tables
    - `rides`
      - `id` (uuid, primary key)
      - `pickup_lat` (float)
      - `pickup_lng` (float) 
      - `dropoff_lat` (float)
      - `dropoff_lng` (float)
      - `status` (text)
      - `time` (text)
      - `customer` (text)
      - `pickup_address` (text)
      - `dropoff_address` (text)
      - `can_start` (boolean)
      - `passengers` (integer)
      - `luggage` (integer)
      - `vehicle_type` (text)
      - `payment_type` (text)
      - `payment_amount` (text)
      - `dispatcher_info` (jsonb)
      - `driver_info` (jsonb)
      - `vehicle_info` (jsonb)
      - `order_info` (jsonb)
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)
      - `driver_id` (uuid, foreign key)

    - `messages`
      - `id` (uuid, primary key)
      - `ride_id` (uuid, foreign key)
      - `text` (text)
      - `translated` (text)
      - `sender` (text)
      - `created_at` (timestamptz)

  2. Security
    - Enable RLS on both tables
    - Add policies for authenticated users to read/write their own data
*/

-- Create rides table
CREATE TABLE rides (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  pickup_lat float NOT NULL,
  pickup_lng float NOT NULL,
  dropoff_lat float NOT NULL,
  dropoff_lng float NOT NULL,
  status text NOT NULL,
  time text NOT NULL,
  customer text NOT NULL,
  pickup_address text NOT NULL,
  dropoff_address text NOT NULL,
  can_start boolean DEFAULT false,
  passengers integer NOT NULL,
  luggage integer NOT NULL,
  vehicle_type text NOT NULL,
  payment_type text NOT NULL,
  payment_amount text NOT NULL,
  dispatcher_info jsonb NOT NULL,
  driver_info jsonb NOT NULL,
  vehicle_info jsonb NOT NULL,
  order_info jsonb NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  driver_id uuid REFERENCES auth.users(id)
);

-- Create messages table
CREATE TABLE messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  ride_id uuid REFERENCES rides(id) ON DELETE CASCADE,
  text text NOT NULL,
  translated text NOT NULL,
  sender text NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE rides ENABLE ROW LEVEL SECURITY;
ALTER TABLE messages ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Users can read own rides"
  ON rides
  FOR SELECT
  TO authenticated
  USING (auth.uid() = driver_id);

CREATE POLICY "Users can insert own rides"
  ON rides
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = driver_id);

CREATE POLICY "Users can update own rides"
  ON rides
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = driver_id);

CREATE POLICY "Users can read messages for their rides"
  ON messages
  FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM rides
      WHERE rides.id = messages.ride_id
      AND rides.driver_id = auth.uid()
    )
  );

CREATE POLICY "Users can insert messages for their rides"
  ON messages
  FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM rides
      WHERE rides.id = messages.ride_id
      AND rides.driver_id = auth.uid()
    )
  );