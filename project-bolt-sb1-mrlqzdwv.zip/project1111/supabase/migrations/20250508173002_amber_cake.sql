/*
  # Update clients table RLS policies

  1. Security Changes
    - Enable RLS on clients table (if not already enabled)
    - Add policy for authenticated users to insert new clients
    - Add policy for authenticated users to read all clients
    - Add policy for authenticated users to update clients
    - Add policy for authenticated users to delete clients

  Note: These policies allow authenticated users to manage all clients, which is
  appropriate for this business application where users need access to the full
  client database.
*/

-- Enable RLS
ALTER TABLE clients ENABLE ROW LEVEL SECURITY;

-- Drop existing policies if they exist
DROP POLICY IF EXISTS "Users can insert clients" ON clients;
DROP POLICY IF EXISTS "Users can read clients" ON clients;
DROP POLICY IF EXISTS "Users can update clients" ON clients;

-- Create new policies
CREATE POLICY "Users can insert clients"
ON clients FOR INSERT
TO authenticated
WITH CHECK (true);

CREATE POLICY "Users can read clients"
ON clients FOR SELECT
TO authenticated
USING (true);

CREATE POLICY "Users can update clients"
ON clients FOR UPDATE
TO authenticated
USING (true)
WITH CHECK (true);

CREATE POLICY "Users can delete clients"
ON clients FOR DELETE
TO authenticated
USING (true);